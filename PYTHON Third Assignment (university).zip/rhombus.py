import math

def rhombus_area(d1, d2):
    return (d1 * d2) / 2

print(rhombus_area(10, 5)) 