def greet(name, greeting="Hello"):
    print(f"{greeting}, {name}!")

greet("Qadeer")  
greet("Taif", "Hi")  