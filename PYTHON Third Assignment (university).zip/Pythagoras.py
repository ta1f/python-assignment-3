import math

def pythagoras(a, b):
    return math.sqrt(a**2 + b**2)

print(pythagoras(3, 4))