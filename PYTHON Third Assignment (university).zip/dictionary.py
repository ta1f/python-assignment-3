students = {"TAIF": 85, "QADEER": 90, "MUFAIZ": 95}
print(students["QADEER"]) 