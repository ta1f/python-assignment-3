def type_checker(value):
    return type(value)

print(type_checker(42))   
print(type_checker("Hello")) 